<!DOCTYPE html>
<html lang="en">
<head>
    <title>Broken Router</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <link rel="stylesheet" href="/css/bootstrap.min.css" type="text/css" media="screen" />
</head>
<body>
    <div class="container">
        <div class="card mt-5">
            <div class="card-header h4 text-center">Update Result</div>
            <div class="card-body">
                <div>
                    <span class="h4"><?php echo('Version: 1.1 updated!'); ?></span>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
